*****************installs*********************

download node from : https://nodejs.org/en/download/

Install Angular CLI: $ npm install -g @angular/cli

For this project the below versions were used
Angular CLI: 7.2.2
Node: 8.12.0




********************Run project*********

In terminal, navigate to the "snake-game" folder. 

Run the following commands: 

npm install

ng serve -o
