import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css'],

  // keep track of buttons pressed with DOM
  // tslint:disable-next-line: use-host-property-decorator
  host: {
    '(document:keyup)': 'triggerKeyBoardMovement($event)'
  }
})
export class GameComponent implements OnInit {
  board: any;
  score: number;

  obstacles = [];
  PLAY_AREA_SIZE = 20;
  isGameOver = false;
  isGameStarted = false;

  currentDirection: number;

  // keyboard direction values
  CONTROLS = {
    LEFT: 37,
    UP: 38,
    RIGHT: 39,
    DOWN: 40
  };

  // full game color scheme
  COLORS = {
    BOARD: '#8BC34A',
    GAME_OVER: '#D24D57',
    FOOD: '#FFA000',
    POWER_UP: 'red',
    HEAD: '#616161',
    BODY: '#CFD8DC',
    OBSTACLE: '#212121'
  };

  snake = {
    // default direction
    direction: this.CONTROLS.LEFT,
    segments: [
      {
        x: -1,
        y: -1
      }
    ]
  };

  food = {
    x: -1,
    y: -1
  };

  constructor() {}

  ngOnInit() {
    console.log('in');
    this.setupBoard();
  }

  startGame() {
    this.isGameStarted = true;
    this.score = 0;
    this.currentDirection = this.CONTROLS.LEFT;
    this.isGameOver = false;
    this.snake = {
      direction: this.CONTROLS.LEFT,
      segments: []
    };

    for (let i = 0; i < 3; i++) {
      this.snake.segments.push({ x: 8 + i, y: 8 });
    }
    this.obstacles = [];
    // add 3 obstacles
    for (let j = 0; j < 3; j++) {
      this.addObstacles();
    }

    this.createFood();
    this.updatePositions();
  }

  setupBoard() {
    this.board = [];
    for (let i = 0; i < this.PLAY_AREA_SIZE; i++) {
      this.board[i] = [];

      // setting cells to false, to keep track of snake position on borad
      for (let j = 0; j < this.PLAY_AREA_SIZE; j++) {
        this.board[i][j] = false;
      }
    }
  }

  setGamePlayColors(col: number, row: number) {
    if (this.isGameOver) {
      return this.COLORS.GAME_OVER;
    } else if (this.food.x === row && this.food.y === col) {
      return this.COLORS.FOOD;
    } else if (
      this.snake.segments[0].x === row &&
      this.snake.segments[0].y === col
    ) {
      return this.COLORS.HEAD;
    } else if (this.board[col][row] === true) {
      return this.COLORS.BODY;
    } else if (this.checkObstacles(row, col)) {
      return this.COLORS.OBSTACLE;
    }

    return this.COLORS.BOARD;
  }

  triggerKeyBoardMovement(e: KeyboardEvent) {
    // Direcion logic (e.g if snake is going right it cannot go left)
    if (
      e.keyCode === this.CONTROLS.LEFT &&
      this.snake.direction !== this.CONTROLS.RIGHT
    ) {
      this.currentDirection = this.CONTROLS.LEFT;
    } else if (
      e.keyCode === this.CONTROLS.UP &&
      this.snake.direction !== this.CONTROLS.DOWN
    ) {
      this.currentDirection = this.CONTROLS.UP;
    } else if (
      e.keyCode === this.CONTROLS.RIGHT &&
      this.snake.direction !== this.CONTROLS.LEFT
    ) {
      this.currentDirection = this.CONTROLS.RIGHT;
    } else if (
      e.keyCode === this.CONTROLS.DOWN &&
      this.snake.direction !== this.CONTROLS.UP
    ) {
      this.currentDirection = this.CONTROLS.DOWN;
    }
  }

  checkObstacles(x, y) {
    let result = false;

    for (let i = 0; i < this.obstacles.length; i++) {
      if (this.obstacles[i].x === x && this.obstacles[i].y === y) {
        result = true;
      }
    }

    return result;
  }

  generateRandomNumber(): any {
    return Math.floor(Math.random() * this.PLAY_AREA_SIZE);
  }

  addObstacles(): void {
    const x = this.generateRandomNumber();
    const y = this.generateRandomNumber();

    if (this.board[y][x] === true) {
      return this.addObstacles();
    }

    this.obstacles.push({
      x: x,
      y: y
    });
  }

  createFood(): void {
    const x = this.generateRandomNumber();
    const y = this.generateRandomNumber();

    if (this.board[y][x] === true || this.checkObstacles(x, y)) {
      return this.createFood();
    }

    this.food = {
      x: x,
      y: y
    };
  }

  updatePositions(): void {
    const newHead = this.repositionHead();

    this.noWallsTransition(newHead);

    if (this.checkObstacles(newHead.x, newHead.y)) {
      return this.gameOver();
    } else if (this.hitSelf(newHead)) {
      return this.gameOver();
    } else if (this.hitFood(newHead)) {
      this.eatFood();
    }

    // movement effect
    const oldTail = this.snake.segments.pop();
    this.board[oldTail.y][oldTail.x] = false;

    this.snake.segments.unshift(newHead);
    this.board[newHead.y][newHead.x] = true;

    this.snake.direction = this.currentDirection;

    setTimeout(() => {
      this.updatePositions();
    }, 180);
  }

  repositionHead(): any {
    const newHead = Object.assign({}, this.snake.segments[0]);

    if (this.currentDirection === this.CONTROLS.LEFT) {
      newHead.x -= 1;
    } else if (this.currentDirection === this.CONTROLS.RIGHT) {
      newHead.x += 1;
    } else if (this.currentDirection === this.CONTROLS.UP) {
      newHead.y -= 1;
    } else if (this.currentDirection === this.CONTROLS.DOWN) {
      newHead.y += 1;
    }

    return newHead;
  }

  noWallsTransition(part: any): void {
    if (part.x === this.PLAY_AREA_SIZE) {
      part.x = 0;
    } else if (part.x === -1) {
      part.x = this.PLAY_AREA_SIZE - 1;
    }

    if (part.y === this.PLAY_AREA_SIZE) {
      part.y = 0;
    } else if (part.y === -1) {
      part.y = this.PLAY_AREA_SIZE - 1;
    }
  }

  eatFood() {
    this.score++;

    const tail = Object.assign(
      {},
      this.snake.segments[this.snake.segments.length - 1]
    );

    this.snake.segments.push(tail);
    this.createFood();
  }

  hitSelf(part: any) {
    // if cell is true, snake is in that area
    return this.board[part.y][part.x] === true;
  }

  hitFood(part: any) {
    return part.x === this.food.x && part.y === this.food.y;
  }

  // hitPowerUp(part: any) {
  //   return (
  //     part.x === this.food.x &&
  //     part.y === this.food.y &&
  //   );
  // }

  gameOver(): void {
    this.isGameOver = true;
    this.isGameStarted = false;
    const _th = this;

    setTimeout(() => {
      _th.isGameOver = false;
    }, 500);

    this.setupBoard();
  }
}
